<?php


namespace App\Controller;


use App\Entity\Product;
use App\Form\ProductType;
use App\Repository\ProductRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class ProductController extends AbstractController
{
    /**
     * @Route("/", name="products")
     */
    public function  products(ProductRepository $productRepository)
    {
        $products = $productRepository->findAll();

        return $this->render('product/product.html.twig', ['products' => $products]);
    }

    /**
     * @Route("/product/{id}", name="product")
     */
    public function  product($id, ProductRepository $productRepository)
    {
        $product = $productRepository->findOneBy(['id' => $id]);

        return $this->render('product/productId.html.twig', ['productId' => $product]);
    }

    /**
     * @Route("/product/delete/{id}", name="productDelete")
     */
    public function  productDelete($id,
                                   ProductRepository $productRepository,
                                   EntityManagerInterface $entityManager)
    {
        $product = $productRepository->findOneBy(['id' => $id]);

        $entityManager->remove($product);
        $entityManager->flush();

        return $this->redirectToRoute('products');
    }

    /**
     * @Route("/productInsert", name="productInsert")
     */
    public function productInsert(Request $request)
    {
        //action
        $product = new Product();

        $formulaire = $this->createForm(ProductType::class, $product);

        $formulaire->handleRequest($request);

        //return
        return $this->render('product/productInsert.html.twig', [
            'formulaire' => $formulaire->createView()
        ]);
    }

}