<?php

namespace Container8ZYDaYk;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder015ee = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer03baf = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties5b10e = [
        
    ];

    public function getConnection()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getConnection', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getMetadataFactory', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getExpressionBuilder', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'beginTransaction', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getCache', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getCache();
    }

    public function transactional($func)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'transactional', array('func' => $func), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->transactional($func);
    }

    public function commit()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'commit', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->commit();
    }

    public function rollback()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'rollback', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getClassMetadata', array('className' => $className), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'createQuery', array('dql' => $dql), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'createNamedQuery', array('name' => $name), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'createQueryBuilder', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'flush', array('entity' => $entity), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'clear', array('entityName' => $entityName), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->clear($entityName);
    }

    public function close()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'close', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->close();
    }

    public function persist($entity)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'persist', array('entity' => $entity), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'remove', array('entity' => $entity), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'refresh', array('entity' => $entity), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'detach', array('entity' => $entity), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'merge', array('entity' => $entity), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getRepository', array('entityName' => $entityName), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'contains', array('entity' => $entity), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getEventManager', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getConfiguration', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'isOpen', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getUnitOfWork', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getProxyFactory', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'initializeObject', array('obj' => $obj), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'getFilters', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'isFiltersStateClean', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'hasFilters', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return $this->valueHolder015ee->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer03baf = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder015ee) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder015ee = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder015ee->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, '__get', ['name' => $name], $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        if (isset(self::$publicProperties5b10e[$name])) {
            return $this->valueHolder015ee->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder015ee;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder015ee;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder015ee;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder015ee;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, '__isset', array('name' => $name), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder015ee;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder015ee;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, '__unset', array('name' => $name), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder015ee;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder015ee;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, '__clone', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        $this->valueHolder015ee = clone $this->valueHolder015ee;
    }

    public function __sleep()
    {
        $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, '__sleep', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;

        return array('valueHolder015ee');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer03baf = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer03baf;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer03baf && ($this->initializer03baf->__invoke($valueHolder015ee, $this, 'initializeProxy', array(), $this->initializer03baf) || 1) && $this->valueHolder015ee = $valueHolder015ee;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder015ee;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder015ee;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
